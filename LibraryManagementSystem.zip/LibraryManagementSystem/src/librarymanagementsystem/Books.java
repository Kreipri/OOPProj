
package librarymanagementsystem;

/**
 *
 * @author 202312049
 */

public class  Books {
    private String bookName;
    private int stocks;
}
